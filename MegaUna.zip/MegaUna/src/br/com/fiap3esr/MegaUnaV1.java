package br.com.fiap3esr;

import java.util.Scanner;

public class MegaUnaV1 {
    public static void main(String[] args) {
        // Declarando as variáveis
        Scanner sc = new Scanner(System.in);
        int numEscolhido;
        int numSorteado = 49;
        String resposta;

        // Informações do Usuário
        System.out.println("Bem-vindo ao Mega Una!");
        System.out.println("Neste jogo, um número será sorteado. Você é capaz de adivinhar?");

        System.out.println("Digite um número entre 1 e 100: ");

        // Atribuindo ao número escolhido o objeto do Scanner
        numEscolhido = sc.nextInt();

        if (numEscolhido == numSorteado){
            System.out.println("Parabéns! Você ganhouuuuuu!");
        } else{
            System.out.println("Que pena, não foi desta vez! Tente novamente na próxima!");
        }

        // Jogando mais vezes
        System.out.println("Gostaria de continuar tentando?");
        resposta = sc.next();

        while(resposta.equalsIgnoreCase("sim")){
            // Inserindo o código lá de cima
        }

        // Avisar que acabou o jogo
        System.out.println("Fim de jogo!");
    }
}
